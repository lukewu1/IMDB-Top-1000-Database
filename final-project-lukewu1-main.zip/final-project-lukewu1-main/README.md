<img src="https://www.colorado.edu/cs/profiles/express/themes/ucb/images/cu-boulder-logo-text-black.svg" alt="CU Boulder Logo" width="500">

# CSCI 2270: Data Structures <br/> IMDB Movies Database Project

1) I used chaining as my hash collision resolution method because I understood how to implement it more than linear probing. Also, since we got the next pointer already it was definitely just more easier to implement for me.

2) My hash function calculates the first value(index) by adding up all of the asci values of the characters in the title string. Then, I added up all of the asci values of each character in my identikey(luwu8831) into the variable tablesize. Finally, I do index%tablesize to calculate the hash index.

3) Yes I implemented the skip list to search for data efficiently using the director's name. # IMDB-Top-1000-Database
